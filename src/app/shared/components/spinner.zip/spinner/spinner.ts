import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-spinner',
  imports: [],
  templateUrl: './spinner.html',
  styleUrl: './spinner.css',
})
export class Spinner {
  @Input() isLoading: boolean = false; // Controla la visibilidad del spinner
  @Input() message: string = ''; // Mensaje opcional

}
